let droneX = 100;
let signalAngle = 0;

function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(200, 240, 255);
  drawField();
  drawTech();
  drawDrone();

  droneX += 1;
  if (droneX > width) droneX = -50;

  signalAngle += 0.05;
}

function drawField() {
  fill(100, 200, 100);
  rect(0, 300, width, 100); // solo

  // Plantas
  fill(34, 139, 34);
  for (let i = 50; i < width / 2; i += 40) {
    rect(i, 270, 10, 30);
  }

  // Sensores no campo
  fill(180);
  for (let i = 60; i < width / 2; i += 80) {
    rect(i, 290, 5, 20);
    ellipse(i + 2.5, 285, 10, 10);
    stroke(0, 100, 255);
    line(i + 2.5, 285, width - 100, 150); // ligação à antena
    noStroke();
  }
}

function drawTech() {
  // Antena de dados
  fill(150);
  rect(width - 100, 200, 10, 100);
  triangle(width - 110, 200, width - 95, 150, width - 80, 200);
  ellipse(width - 100, 145, 15, 15);

  // Linhas de "dados"
  stroke(0, 100, 255, 100);
  for (let y = 290; y < 300; y += 5) {
    line(width - 100, 150, width / 2, y);
  }
  noStroke();
}

function drawDrone() {
  // Drone corpo
  fill(80);
  ellipse(droneX, 150, 40, 20);
  
  // Hélices
  fill(50);
  ellipse(droneX - 20, 140, 15, 5);
  ellipse(droneX + 20, 140, 15, 5);

  // Sinal descendo do drone
  stroke(0, 255, 0);
  noFill();
  for (let r = 0; r < 3; r++) {
    arc(droneX, 170, 20 + r * 10, 10 + r * 5, 0, PI);
  }
  noStroke();
}
